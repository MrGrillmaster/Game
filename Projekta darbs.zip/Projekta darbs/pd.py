#1.Sistēmu analīze
#2.Sistēmas projektēšanu
#3.Programatūras izstrāde
#4.Testēšana
#5.Izlaišana un uzturēšana

